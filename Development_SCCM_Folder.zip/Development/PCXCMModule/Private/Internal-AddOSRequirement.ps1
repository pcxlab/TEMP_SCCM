function Add-InternalOSRequirement {
    param (
        [Parameter(Mandatory)] [string] $AppName,
        [Parameter(Mandatory)] [string] $SiteCode,
        [Parameter(Mandatory)] [string] $SiteServer,
        [Parameter(Mandatory)] [string] $Requirement,
        [Parameter(Mandatory)] [string] $ValidateSetFile
    )

    try {
        if (-not (Get-PSDrive $SiteCode -ErrorAction SilentlyContinue)) {
            New-PSDrive -Name $SiteCode -PSProvider "AdminUI.PS.Provider\CMSite" -Root $SiteServer
        }

        Set-Location "$SiteCode`:"
        $App = Get-CMApplication -Name $AppName -ErrorAction Stop
        $xml = [Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer]::DeserializeFromString($App.SDMPackageXML, $True)

        $namedPairs = @{}
        foreach ($line in Get-Content $ValidateSetFile) {
            $parts = $line -split ","
            $namedPairs[$parts[0]] = $parts[1]
        }

        $operand = $namedPairs[$Requirement]

        $updated = $false
        foreach ($dt in $xml.DeploymentTypes) {
            foreach ($req in $dt.Requirements) {
                if ($req.Expression -is [Microsoft.ConfigurationManagement.ApplicationManagement.OperatingSystemExpression]) {
                    if ($req.Name -notlike "*$Requirement*") {
                        $req.Expression.Operands.Add($operand)
                        $req.Name = "$($req.Name), $Requirement"
                        $req.RuleId = "Rule_$([guid]::NewGuid())"
                        $dt.Requirements.Remove($req)
                        $dt.Requirements.Add($req)
                        $updated = $true
                        break
                    }
                }
            }
        }

        if ($updated) {
            $App.SDMPackageXML = [Microsoft.ConfigurationManagement.ApplicationManagement.Serialization.SccmSerializer]::SerializeToString($xml, $True)
            Set-CMApplication -InputObject $App -PassThru | Out-Null
            return [pscustomobject]@{
                ApplicationName = $AppName
                Status          = "Updated"
                PackageID       = $App.PackageID
                CIVersion       = $App.CIVersion
                ModifiedBy      = $App.LastModifiedBy
                ModifiedDate    = $App.DateLastModified
            }
        } else {
            return [pscustomobject]@{
                ApplicationName = $AppName
                Status          = "Already Exists"
                PackageID       = $App.PackageID
                CIVersion       = $App.CIVersion
                ModifiedBy      = $App.LastModifiedBy
                ModifiedDate    = $App.DateLastModified
            }
        }
    } catch {
        Write-Error "❌ Error with app '$AppName': $_"
        return [pscustomobject]@{
            ApplicationName = $AppName
            Status          = "Error"
            PackageID       = $null
            CIVersion       = $null
            ModifiedBy      = $null
            ModifiedDate    = $null
        }
    }
}

# SIG # Begin signature block
# MIIKmwYJKoZIhvcNAQcCoIIKjDCCCogCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUyOYA2v+PD7Ni4hz2SdankLfB
# dtOgggfxMIIH7TCCBdWgAwIBAgITfgAqDS38gi3RBcr9PwAAACoNLTANBgkqhkiG
# 9w0BAQsFADBcMRMwEQYKCZImiZPyLGQBGRYDY29tMRcwFQYKCZImiZPyLGQBGRYH
# bXBoYXNpczEUMBIGCgmSJomT8ixkARkWBGNvcnAxFjAUBgNVBAMTDU1waGFzaXNS
# b290Q0EwHhcNMjUwMTI3MTIxNTE1WhcNMjcwMTI3MTIxNTE1WjCBuTETMBEGCgmS
# JomT8ixkARkWA2NvbTEXMBUGCgmSJomT8ixkARkWB21waGFzaXMxFDASBgoJkiaJ
# k/IsZAEZFgRjb3JwMR0wGwYDVQQLExRNcGhhc2lTIEJQTyBTZXJ2aWNlczESMBAG
# A1UECxMJTWFuZ2Fsb3JlMRQwEgYDVQQLEwtNb3JnYW4gR2F0ZTESMBAGA1UECxMJ
# QWxsIFVzZXJzMRYwFAYDVQQDEw1IYXJzaGl0aHJhaiBQMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAxMQa6w0z2RxDuXsD42TVI+y6pNJGSfctL3Wo7FlZ
# 13PDFGwzrJ+MHYrHdXbTDXx9QNwRmp1XEACLBzXvtfkTvptoJXm8S5an710FmIhQ
# X1UaRtMBmxcPHPXYx9srPo/IrspfzjjfzIcA3iyV/kPp/BHc5TAUTwtkaUVDOfsr
# Eo+f0AkJTZY3+4U39rvVSh3Tymo8yett0lFMG+Mo8XoGxXhjmcDYr4WgdPnmRUf7
# 2NprzPYTAr9+CgiAMMlI2oEFVhevReXiYWI8NeBlnDxHF3Wz8vapN82qO/AyCvsu
# 9A8HWsFdKynYlgmqjcEFeq5LTDkqBG40M+mwUwlmrkfdHQIDAQABo4IDSDCCA0Qw
# OwYJKwYBBAGCNxUHBC4wLAYkKwYBBAGCNxUIhMyCH8+9G4LVjRuzxzWGhuksgUCG
# mfcDrJoTAgFkAgEOMBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAb
# BgkrBgEEAYI3FQoEDjAMMAoGCCsGAQUFBwMDMFIGCSsGAQQBgjcZAgRFMEOgQQYK
# KwYBBAGCNxkCAaAzBDFTLTEtNS0yMS0xMDc5NTc2NTIzLTM4NTgxMjM1NjUtMTkw
# OTY3OTkxNS05NTg5MDQyME8GA1UdEQRIMEagKQYKKwYBBAGCNxQCA6AbDBlIYXJz
# aGl0aHJhai5QQG1waGFzaXMuY29tgRlIYXJzaGl0aHJhai5QQG1waGFzaXMuY29t
# MB0GA1UdDgQWBBSkZDx6EbPefW2Ud8IXKJ6tZ3dLPzAfBgNVHSMEGDAWgBQjRSRz
# 1j1XGGn4I9WpMcdUqHHtjTCB2wYDVR0fBIHTMIHQMIHNoIHKoIHHhoHEbGRhcDov
# Ly9DTj1NcGhhc2lzUm9vdENBLENOPVNSVkJBTjA5Q1JBVVZNMSxDTj1DRFAsQ049
# UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049U2VydmljZXMsQ049Q29uZmlndXJh
# dGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9Y29tP2NlcnRpZmljYXRlUmV2b2Nh
# dGlvbkxpc3Q/YmFzZT9vYmplY3RDbGFzcz1jUkxEaXN0cmlidXRpb25Qb2ludDCC
# AQEGCCsGAQUFBwEBBIH0MIHxMIG0BggrBgEFBQcwAoaBp2xkYXA6Ly8vQ049TXBo
# YXNpc1Jvb3RDQSxDTj1BSUEsQ049UHVibGljJTIwS2V5JTIwU2VydmljZXMsQ049
# U2VydmljZXMsQ049Q29uZmlndXJhdGlvbixEQz1jb3JwLERDPW1waGFzaXMsREM9
# Y29tP2NBQ2VydGlmaWNhdGU/YmFzZT9vYmplY3RDbGFzcz1jZXJ0aWZpY2F0aW9u
# QXV0aG9yaXR5MDgGCCsGAQUFBzABhixodHRwOi8vU1JWQkFOMDlDUkFVVk0xLmNv
# cnAubXBoYXNpcy5jb20vb2NzcDANBgkqhkiG9w0BAQsFAAOCAgEAK86w/bs3xZR1
# wCj+aHRSPYtMjPWaBV1x7FYIRUI4cYUWh8/LSXd+SeecR9ZILHv98WmpHHSCANMm
# AjmLx0GufMz1IS+CuWrMmbtWA81zlYICoCMC8sNGoOHAm16njFwm09Yj0/7lB5OA
# UMbPdy1FoL7FTrOTgnWElBxbZZd4DyEKfC4f+f+6L7cIrFgXiansLLiYy8mTHNUW
# /T4ZipxPYMdcKXkItY94NCsQzccy12xDI8JCd2PFk5p8IVE85yUxP7xT9jc7ZSKg
# AGOuwJ9PDWAFMXQe8DmYyVCrrw0oVn0t7OWcmBsjId8kUjm1kq+lUcMyx+xwhO6q
# 8DbgqFekH6KLJA/fKsSGgxInpqvJzQ9ExTpAuxATrdTZkrlfkIEArqp1DPBMBF7+
# 2pewhdwF3PWqd1zRI1Phmo6lm4ixUST0sVRygV+PT5KuDWVCnrkD39rGn2XcZ5Tk
# /+0eezAMjG4xnXmwja7pu3h0jcDwt7RQoLKKMHc70pFiyKGr5lY5/jWLClFLh3RV
# 7Z/2zKRTRf8NL/uiiS6z9Qv7vuZZ+IqrzB4XxPdCytpKZwoy4vSxBFob6syDLc2r
# FaTctXl3Yg27zp4NYG0+CP+y6fsGw2V6g4zz50wp1SAmWkLL7WK2e3gDzbdUrXq2
# WD+POBA6s8795fJpOk+tkFSY8SENWR0xggIUMIICEAIBATBzMFwxEzARBgoJkiaJ
# k/IsZAEZFgNjb20xFzAVBgoJkiaJk/IsZAEZFgdtcGhhc2lzMRQwEgYKCZImiZPy
# LGQBGRYEY29ycDEWMBQGA1UEAxMNTXBoYXNpc1Jvb3RDQQITfgAqDS38gi3RBcr9
# PwAAACoNLTAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZ
# BgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYB
# BAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUs2OG+ycITe7K9D/UgargD046EIYwDQYJ
# KoZIhvcNAQEBBQAEggEAF8IWPAk5V81NLeIRszeUB546Iy3VLNl7eppEk8GBHKoZ
# rXqYui14MZa8XKUnoLCmDry88iaEefWiUBhRjPRxWOw7xubzld7Hp2sQfR5nAkKy
# p1cvG/GJvUjClx838gbzYSVVXDCqDgYjj6Z+p2EaxnZYEL3q1BRdOPlxFGalhNiw
# Y/a9Rn3hW1LE2e3PRcJlm5X3zIQXVAUauv6BDsFL6hhJ2Tmsmy8Vf0m+n94xd7hd
# yBjzUoXN6KNiSmgFQC8vVkbfRm4TQJXh//u9/yUoYr6/tbDhU9lg6r8iAFfmi8JF
# zQhUnJlM37VImwUiApQduHFZelqiwMkuEF84MuRTUw==
# SIG # End signature block
