﻿<#
.SYNOPSIS
    PowerShell Automated Collection Creation Script for SCCM deployments 
.DESCRIPTION
    This PowerShell script automates the process of creating collections for SCCM deployments. 
    It streamlines collection creation, query addition, membership management (including inclusion and exclusion), 
    and selection of limiting collections. The script includes robust error handling and informative user messages. 
    It also verifies the availability of specified include collections and organizes collections within console folders.
.FEATURES
    - Automated collection creation and management
    - Error handling with user-friendly messages
    - Verification of include collection availability
    - Organizes collections within console folders
    - Automatic date capture and conversion
.STATISTICS
    - Total Folders Created: xx
    - Total Collections Created: xx
    - Total Queries Created: xx
    - Total Include Memberships Created: xx
    - Total Exclude Memberships Created: xx
    - Total Collection Movements: xx
    - Total Lines of Code: <500 (subject to functional additions or deletions)
.AUTHOR
    RB HR
.TESTERS
    RB HR
.APROVALS
    Pre Reseles Beta Versions
.LASTMODIFIED
    10 Jan 2023
.NOTES
    Version: 2.4.9
- Last modified: 17 Jun 2025

SMS Collections_V25.01 = added index 0 to SiteCode - geting double index of SiteCode 
function Get-SCCMSiteCode Updated Index 
return $siteCode[0]


#>
# Program begins here... NJoy...
# Function to get Year and month Automatic  #...............................................................................................................................................................................
function Get-YearMonth {
    $now = Get-Date
    $year = $now.Year
    $month = $now.Month.ToString("00")
    return "$year-$month"
}
$yearMonth = Get-YearMonth
Write-Output "Current Year and Month: $yearMonth"
# Function to get the month name abbreviated Month Name  #...............................................................................................................................................................................
function Get-AbbreviatedMonthName {
    param(
        [datetime]$date
    )
$abbreviatedMonth = $date.ToString("MMM")
    return $abbreviatedMonth
}
$today = Get-Date
$abbreviatedMonth = Get-AbbreviatedMonthName -date $today
Write-Host "Abbreviated Month Name: $abbreviatedMonth"

# Forground Color code
$ColScuccess = "Green"
$ColError = "Red"
$ColInform = "Yellow"

# Site configuration
# $SiteCode = "EZY" # Site code 
# Get SCCM Site code

function Get-SCCMSiteCode {
    try {
        $siteCode = Get-WmiObject -Namespace "Root\SMS" -Class SMS_ProviderLocation -ComputerName "." | Select-Object -ExpandProperty SiteCode
        if ($siteCode -ne $null) {
            if ($siteCode -is [array]) {
                return $siteCode[0]
            } else {
                return $siteCode
            }
        } else {
            Write-Output "SCCM Site Code not found."
            return $null
        }
    } catch {
        Write-Error "Error retrieving SCCM Site Code: $_"
        return $null
    }
}

# Call the function and assign the result to a variable
$SiteCode = Get-SCCMSiteCode

# Check if the site code was retrieved successfully
if ($SiteCode -ne $null) {
    Write-Output "Assigned SCCM Site Code is: $SiteCode"
} else {
    Write-Output "Failed to retrieve SCCM Site Code."
    exit 0
}

# FQDN
# $ProviderMachineName = "SESRVER.eaz.net" # SMS Provider machine name

# Get FQDN
function Get-SystemFQDN {
    try {
        $fqdn = [System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName
        if ($fqdn -ne $null) {
            return $fqdn
        } else {
            Write-Output "FQDN not found."
            return $null
        }
    } catch {
        Write-Error "Error retrieving FQDN: $_"
        return $null
    }
}

# Call the function and assign the result to a variable
$ProviderMachineName = Get-SystemFQDN

# Check if the FQDN was retrieved successfully
if ($ProviderMachineName -ne $null) {
    Write-Output "Assigned FQDN is: $ProviderMachineName"
} else {
    Write-Output "Failed to retrieve FQDN."
    exit 0
}

# Test Site Config
# $SiteCode = "PS1" # Site code 
# $ProviderMachineName = "CM01.corp.pcxlab.com" # SMS Provider machine name

# Customizations
$initParams = @{}
#$initParams.Add("Verbose", $true) # Uncomment this line to enable verbose logging
#$initParams.Add("ErrorAction", "Stop") # Uncomment this line to stop the script on any errors
# Do not change anything below this line
# Import the ConfigurationManager.psd1 module 
if ((Get-Module ConfigurationManager) -eq $null) {
    Import-Module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams 
}
# Connect to the site's drive if it is not already present
if ((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null) {
    New-PSDrive -Name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams
}
# Set the current location to be the site code.
Set-Location "$($SiteCode):\" @initParams
# Function to create folder under sccm console #...............................................................................................................................................................................

# Introduce try catch method
<# Function Create-Folder {
    param(
        [string]$Path,
        [string]$Name
    )
if (-not (Test-Path -Path (Join-Path $Path $Name))) {
        try {
            New-Item -Path $Path -Name $Name -ItemType Directory -ErrorAction Stop
            Write-Host "Folder '$Name' created successfully at $Path\." -ForegroundColor $ColScuccess
        }
        catch {
            Write-Host "Error creating folder: $_" -ForegroundColor $ColError
        }
    }
    else {
        Write-Host "Folder '$Name' already exists at '$Path\'." -ForegroundColor $ColInform
    }
}
# Create folders examples with executables
Create-Folder -Path "$($SiteCode):\DeviceCollection" -Name "Test Collections"
Create-Folder -Path "$($SiteCode):\DeviceCollection\Test Collections" -Name "Deployments"
# Create-Folder -Path "$($SiteCode):\DeviceCollection\Test Collections\Deployments" -Name "MS Update - $yearMonth - EZY - Wkstn & WVD"

#>

function Create-Folder {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path,  # Relative to $SiteCode

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Name,

        [switch]$Force,
        [switch]$VerboseOutput
    )

    $fullPath = Join-Path -Path "$($SiteCode):\$Path" -ChildPath $Name

    try {
        if (-not (Test-Path -Path $fullPath)) {
            $null = New-Item -Path $fullPath -ItemType Directory -Force:$Force.IsPresent -ErrorAction Stop
            if ($VerboseOutput) {
                Write-Host "✅ Folder '$Name' created at '$Path'." -ForegroundColor $ColScuccess
            }
            return $true
        } else {
            if ($VerboseOutput) {
                Write-Host "ℹ️ Folder '$Name' already exists at '$Path'." -ForegroundColor $ColInform
            }
            return $false
        }
    } catch {
        Write-Host "❌ Error creating folder '$Name' at '$Path': $_" -ForegroundColor $ColError
        return $false
    }
}


# Define the function to create SCCM collections and move them  #...............................................................................................................................................................................
Function Create-And-MoveCMCollection {
    param(
        [string]$CollectionName,
        [string]$LimitingCollection,
        [string]$FolderPath
    )
# Check if the collection already exists
    $existingCollection = Get-CMDeviceCollection -Name $CollectionName
if (-not $existingCollection) {
        # Collection does not exist, so create it
        New-CMDeviceCollection -Name $CollectionName -LimitingCollectionName $LimitingCollection > $null
        Write-Host "Collection '$CollectionName' with limiting '$LimitingCollection' Created successfully" -ForegroundColor $ColScuccess
    }
    else {
        Write-Host "Collection '$CollectionName' already exists." -ForegroundColor $ColInform
    }
# Get the collection object
    $collectionObject = Get-CMDeviceCollection -Name $CollectionName
# Get the site code (uncomment if required)
    # $siteCode = (Get-CMSite).SiteCode
# Check if $siteCode is defined (uncomment if required)
    # if (-not $siteCode) {
    #     Write-Host "Site code is not defined. Please make sure to uncomment and provide a value for $siteCode."
    #     return
    # }
# Construct the site folder path
    $siteFolderPath = "$siteCode" + ":\$FolderPath"
# Move the collection to the specified folder
    Move-CMObject -FolderPath $siteFolderPath -InputObject $collectionObject
    Write-Host "Collection '$CollectionName' is Moved to '$siteFolderPath\'"
}
# Create and move first SCCM collection
# Usage example
# Create-And-MoveCMCollection -CollectionName "MS Update - $yearMonth - EZY - Wkstn_RPA_NonProd [Install] EZY" -LimitingCollection "All EY RPA/BOT Machines EZY" -FolderPath "DeviceCollection\Security Management Services\Deployments\MS Update - $yearMonth - EZY - Wkstn & WVD"

#Function to Add Query membership   #...............................................................................................................................................................................
Function Add-CMDeviceCollectionQueryMembershipRuleWithQuery {
    Param(
        [string]$CollectionName,
        [string]$QueryExpression,
        [string]$RuleName
    )
Add-CMDeviceCollectionQueryMembershipRule -CollectionName $CollectionName -QueryExpression $QueryExpression -RuleName $RuleName
}

# Add multiple collection function   #...............................................................................................................................................................................
function Add-IncludeCollection {
    [CmdletBinding()]
    param (
        [string]$SelectCollectionName,
        [string[]]$IncludeCollectionNames
    )
try {
        # Get the target collections
        $SelectCollection = Get-CMDeviceCollection -Name $SelectCollectionName
if (-not $SelectCollection) {
            throw "$SelectCollectionName could not be found to add any collection."
        }
# Loop through the source collection names and add them to the target collection
        foreach ($IncludeCollectionName in $IncludeCollectionNames) {
try {
                $IncludeCollection = Get-CMDeviceCollection -Name $IncludeCollectionName
if ($IncludeCollection) {
                    Add-CMDeviceCollectionIncludeMembershipRule -CollectionId $SelectCollection.CollectionId -IncludeCollectionId $IncludeCollection.CollectionId
Write-Host "Successfully added '$($IncludeCollectionName)' to '$($SelectCollectionName)'." -ForegroundColor $ColScuccess
                }
                else {
                    Write-Host "Source collection '$($IncludeCollectionName)' not found." -ForegroundColor $ColInform
                }
}
            catch {
                Write-Host "Include collection '$IncludeCollectionName' to '$SelectCollectionName' got an Error: $_" -ForegroundColor $ColError
            }
        }
    }
    catch {
        Write-Host "Include collection '$IncludeCollectionName' to '$SelectCollectionName' got an Error: $_" -ForegroundColor $ColError
    }
}

# Multiple exclude collection  #...............................................................................................................................................................................
function Add-ExcludeCollection {
    [CmdletBinding()]
    param (
        [string]$SelectCollectionName,
        [string[]]$ExcludeCollectionNames
    )
try {
        # Get the target collections
        $SelectCollection = Get-CMDeviceCollection -Name $SelectCollectionName
if (-not $SelectCollection) {
            throw "$SelectCollectionName could not be found to add any collection."
        }
# Loop through the source collection names and add them to the target collection
        foreach ($ExcludeCollectionName in $ExcludeCollectionNames) {
try {
                $ExcludeCollection = Get-CMDeviceCollection -Name $ExcludeCollectionName
if ($ExcludeCollection) {
                    Add-CMDeviceCollectionExcludeMembershipRule -CollectionId $SelectCollection.CollectionId -ExcludeCollectionId $ExcludeCollection.CollectionId
Write-Host "Successfully added '$($ExcludeCollectionName)' to '$($SelectCollectionName)' as Exclude Membership." -ForegroundColor $ColScuccess
                }
                else {
                    Write-Host "Source collection '$($ExcludeCollectionName)' not found." -ForegroundColor $ColInform
                }
}
            catch {
                Write-Host "Exclude collection '$ExcludeCollectionName' to '$SelectCollectionName' got an Error: $_" -ForegroundColor $ColError
            }
        }
    }
    catch {
        Write-Host "Exclude collection '$ExcludeCollectionName' to '$SelectCollectionName' got an Error: $_" -ForegroundColor $ColError
    }
}
#Add Exclde Membership

# Create folder 
Create-Folder -Path "$($SiteCode):\DeviceCollection\Security Management Services\Deployments" -Name "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn"
# Create and move first SCCM collection
Create-And-MoveCMCollection -CollectionName "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn [Install] EZY" -LimitingCollection "MS 365 Apps Semi-Annual Enterprise Channel (Preview) CDN" -FolderPath "DeviceCollection\Security Management Services\Deployments\MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn"
# Add multiple include collection
Add-IncludeCollection -SelectCollectionName "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn [Install] EZY" -IncludeCollectionNames @("MS 365 Apps Semi-Annual Enterprise Channel (Preview) 2402 x86", "MS 365 Apps Semi-Annual Enterprise Channel (Preview) 2402 x64")
# Add Exclde Membership
Add-ExcludeCollection -SelectCollectionName "MS 365 Apps 2402P Update - $yearMonth - EZY - Wkstn [Install] EZY" -ExcludeCollectionNames @("Desktop Testing Team EZY")
#/          /          /          /          /          /          /          /          /          /          /          /          /          /          /          /          /          /          /

##################################


# Create folder 
Create-Folder -Path "$($SiteCode):\DeviceCollection\Reusable Collection\Deployments" -Name "New FOlder Name"

# Add query to the collection
Create-And-MoveCMCollection -CollectionName "Phase Collection Testing 5% Phase1" -LimitingCollection "All Systems" -FolderPath "DeviceCollection\Test Collections\Deployments"

#DeviceCollection\Test Collections\Deployments
$WVDQuery = 'select SMS_R_SYSTEM.ResourceID,SMS_R_SYSTEM.ResourceType,SMS_R_SYSTEM.Name,SMS_R_SYSTEM.SMSUniqueIdentifier,SMS_R_SYSTEM.ResourceDomainORWorkgroup,SMS_R_SYSTEM.Client from SMS_R_System where SMS_R_System.ResourceId in (select resourceid from SMS_FullCollectionMembership where CollectionID IN ("EZY05506"))'

Add-CMDeviceCollectionQueryMembershipRuleWithQuery -CollectionName "Phase Collection Testing 5% Phase1" -QueryExpression $WVDQuery -RuleName "WVD machines"
# Create and move first SCCM collection


Create-Folder -Path "DeviceCollection\Test Collections\Deployments\ABV" -Name "Three1" -VerboseOutput\

Create-Folder -Path "DeviceCollection\Test Collections\Deployments\ABV\cas\we\longpath\missin" -Name "Three1" 






